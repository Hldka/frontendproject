const PrivacyPolicyPage = () => {
    return <div>PrivacyPolicyPage</div>;
};

export default PrivacyPolicyPage;
