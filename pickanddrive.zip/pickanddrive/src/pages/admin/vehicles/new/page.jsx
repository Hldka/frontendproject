const AdminNewVehiclePage = () => {
    return <div>AdminNewVehiclePage</div>;
};

export default AdminNewVehiclePage;
