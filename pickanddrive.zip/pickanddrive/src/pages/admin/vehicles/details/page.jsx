const AdminVehicleDetailsPage = () => {
    return <div>AdminVehicleDetailsPage</div>;
};

export default AdminVehicleDetailsPage;
