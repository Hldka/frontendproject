const AdminVehiclesPage = () => {
    return <div>AdminVehiclesPage</div>;
};

export default AdminVehiclesPage;
