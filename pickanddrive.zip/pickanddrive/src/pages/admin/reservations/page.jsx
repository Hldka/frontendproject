const AdminReservationsPage = () => {
    return <div>AdminReservationsPage</div>;
};

export default AdminReservationsPage;
