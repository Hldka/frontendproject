const AdminReservationDetailsPage = () => {
    return <div>AdminReservationDetailsPage</div>;
};

export default AdminReservationDetailsPage;
