const AdminUsersPage = () => {
    return <div>AdminUsersPage</div>;
};

export default AdminUsersPage;
