const AdminUserDetailsPage = () => {
    return <div>AdminUserDetailsPage</div>;
};

export default AdminUserDetailsPage;
