const AdminContactMessagesPage = () => {
    return <div>AdminContactMessagesPage</div>;
};

export default AdminContactMessagesPage;
