const AdminContactMessageDetailsPage = () => {
    return <div>AdminContactMessageDetailsPage</div>;
};

export default AdminContactMessageDetailsPage;
