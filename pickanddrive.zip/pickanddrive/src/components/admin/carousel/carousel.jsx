const AdminCarousel = () => {
    return <div>AdminCarousel</div>;
};

export default AdminCarousel;
