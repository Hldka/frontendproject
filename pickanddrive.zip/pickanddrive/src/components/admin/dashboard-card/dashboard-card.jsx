const DashboardCard = () => {
  return (
    <div>DashboardCard</div>
  )
}

export default DashboardCard